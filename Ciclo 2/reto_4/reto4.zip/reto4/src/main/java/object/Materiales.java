package object;

/**
 *
 * @author Cristian Andrey <cristianandrey.github.io/>
 */
public class Materiales extends Libro {

    private String numero = "No Aplica";
    private String volumen = "No Aplica";
    private String tipomaterial;
    private boolean estado_prestamo = false;

    //contructor de libro
    public Materiales(int codigo, String titulo, String tematica_principal, String autor_principal, String año_publicacion, String editorial, String tipomaterial) {
        super(codigo, titulo, tematica_principal, autor_principal, año_publicacion, editorial);
        this.tipomaterial = tipomaterial;
    }

    //contructor de revistas
    public Materiales(String numero, String volumen, int codigo, String titulo, String tematica_principal, String autor_principal, String año_publicacion, String editorial, String tipomaterial) {
        super(codigo, titulo, tematica_principal, autor_principal, año_publicacion, editorial);
        this.numero = numero;
        this.volumen = volumen;
        this.tipomaterial = tipomaterial;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getVolumen() {
        return volumen;
    }

    public void setVolumen(String volumen) {
        this.volumen = volumen;
    }

    public boolean getEstado_prestamo() {
        return estado_prestamo;
    }

    public void setEstado_prestamo(boolean estado_prestamo) {
        this.estado_prestamo = estado_prestamo;
    }

    public String getTipomaterial() {
        return tipomaterial;
    }

    public void setTipomaterial(String tipomaterial) {
        this.tipomaterial = tipomaterial;
    }

}

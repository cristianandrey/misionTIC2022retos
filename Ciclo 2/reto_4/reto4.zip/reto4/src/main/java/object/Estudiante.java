
package object;

/**
 *
 * 
 * @author Cristian Andrey <cristianandrey.github.io/>
 */
public class Estudiante {
    private long documento;
    private String nombre;
    private String email;
    private long celular;
    private String direccion;

    public Estudiante(long documento, String nombre, String email, long celular, String direccion) {
        this.documento = documento;
        this.nombre = nombre;
        this.email = email;
        this.celular = celular;
        this.direccion = direccion;
    }

    public long getDocumento() {
        return documento;
    }

    public void setDocumento(long documento) {
        this.documento = documento;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public long getCelular() {
        return celular;
    }

    public void setCelular(long celular) {
        this.celular = celular;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
    
    
}

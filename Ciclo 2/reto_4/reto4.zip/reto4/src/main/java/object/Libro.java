package object;


/**
 *
 * @author Cristian Andrey <cristianandrey.github.io/>
 */
public class Libro {

    private int codigo;
    private String titulo;
    private String tematica_principal;
    private String autor_principal;
    private String año_publicacion;
    private String editorial;
    
   


    public Libro(int codigo, String titulo, String tematica_principal, String autor_principal, String año_publicacion, String editorial) {
       
        this.codigo = codigo;
        this.titulo = titulo;
        this.tematica_principal = tematica_principal;
        this.autor_principal = autor_principal;
        this.año_publicacion = año_publicacion;
        this.editorial = editorial;
       
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getTematica_principal() {
        return tematica_principal;
    }

    public void setTematica_principal(String tematica_principal) {
        this.tematica_principal = tematica_principal;
    }

    public String getAutor_principal() {
        return autor_principal;
    }

    public void setAutor_principal(String autor_principal) {
        this.autor_principal = autor_principal;
    }

    public String getAño_publicacion() {
        return año_publicacion;
    }

    public void setAño_publicacion(String año_publicacion) {
        this.año_publicacion = año_publicacion;
    }

    public String getEditorial() {
        return editorial;
    }

    public void setEditorial(String editorial) {
        this.editorial = editorial;
    }


   

}

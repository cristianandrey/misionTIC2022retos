package object;

import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Cristian Andrey <cristianandrey.github.io/>
 */
public class TablaMaterialesModelo extends AbstractTableModel {

    private ArrayList<Materiales> datos;
    private String[] columnas = {"Codigo", "Titulo",
        "Tematica Principal", "Autor Principal", "Año Publicacion", "Editorial", "Numero", "Volumen", "Tipo Material", "Estado"};

    public TablaMaterialesModelo(ArrayList<Materiales> datos) {
        this.datos = datos;
    }

    @Override
    public int getRowCount() {
        return datos.size();
    }

    @Override
    public int getColumnCount() {
        return columnas.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Materiales materiales = datos.get(rowIndex);

        switch (columnIndex) {
            case 0:
                return materiales.getCodigo();
            case 1:
                return materiales.getTitulo();
            case 2:
                return materiales.getTematica_principal();
            case 3:
                return materiales.getAutor_principal();

            case 4:
                return materiales.getAño_publicacion();

            case 5:
                return materiales.getEditorial();

            case 6:

                return materiales.getNumero();

            case 7:

                return materiales.getVolumen();

            case 8:
                return materiales.getTipomaterial();
            case 9:
                if (materiales.getEstado_prestamo() == false) {
                    return "Disponible";
                } else {
                    return "Prestado";
                }
            // return materiales.getEstado_prestamo();

            default:
                return "N/A";
        }
    }

    @Override
    public String getColumnName(int column) {
        return columnas[column]; //To change body of generated methods, choose Tools | Templates.
    }

    public void addMaterial(Materiales materiales) {
        this.datos.add(materiales);
    }

    public void deleteMaterial(int index) {
        this.datos.remove(index);
    }

    public void editMaterial(int index, Materiales materiales) {
        this.datos.set(index, materiales);
    }

    public Materiales getElementAt(int index) {
        return this.datos.get(index);
    }

}

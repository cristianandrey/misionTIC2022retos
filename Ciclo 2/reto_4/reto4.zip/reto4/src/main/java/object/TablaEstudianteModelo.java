package object;

import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;

public class TablaEstudianteModelo extends AbstractTableModel {
    private ArrayList<Estudiante> datos;
    private String [] columnas = {"Documento", "Nombre", "Email", "Celular","Direccion"};

    public TablaEstudianteModelo(ArrayList<Estudiante> datos) {
        this.datos = datos;
    }

    @Override
    public int getRowCount() {
        return datos.size();
    }

    @Override
    public int getColumnCount() {
        return columnas.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Estudiante estudiante = datos.get(rowIndex);
       
        switch(columnIndex) {
            case 0: 
                return estudiante.getDocumento();
            case 1:
                return estudiante.getNombre();
            case 2:
                return estudiante.getEmail();
            case 3:
                return estudiante.getCelular();
            case 4:
                return estudiante.getDireccion();
            default:
                return "N/A";
        }
    }

    @Override
    public String getColumnName(int column) {
        return columnas[column]; //To change body of generated methods, choose Tools | Templates.
    }
    
    public void addEstudiante(Estudiante estudiante) {
        this.datos.add(estudiante);
    }
       
    public Estudiante getElementAt(int index) {
        return this.datos.get(index);
    }
    
}

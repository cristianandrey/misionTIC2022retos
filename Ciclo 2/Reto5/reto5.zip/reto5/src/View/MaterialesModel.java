package View;

//import POJO.Materiales;
import POJO.Materiales;
import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Cristian Andrey <cristianandrey.github.io/>
 */
public class MaterialesModel extends AbstractTableModel {

    private ArrayList<Materiales> materiales;
    //private String [] headers = {"id", "Estado", "Codigo", "Titulo", "Tematica", "Año publicacion","Autor principal", "editorial", "numero", "volumen"};
    private String[] columnas = {"id", "Estado", "Tipo Material", "Codigo", "Titulo", "Tematica", "Año publicacion", "Autor principal", "editorial", "numero", "volumen"};

    public MaterialesModel(ArrayList<Materiales> materiales) {
        this.materiales = materiales;
    }

    @Override
    public int getRowCount() {
        return this.materiales.size();
    }

    @Override
    public int getColumnCount() {
        return this.columnas.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Materiales mat = this.materiales.get(rowIndex);
        switch (columnIndex) {
            case 0:
                return mat.getId();
            case 1:
                return mat.getEstado();
            case 2:
                if (mat.getAutorprincipal() == null) {
                    String autor = "Revista";
                    return autor;
                }
                return "Libro";
            case 3:
                return mat.getCodigo();
            case 4:
                return mat.getTitulo();
            case 5:
                return mat.getTematica();
            case 6:
                return mat.getAño_publicacion();
            case 7:
                if (mat.getAutorprincipal() == null) {
                    String autor = "No Aplica";
                    return autor;
                }
                return mat.getAutorprincipal();
            case 8:
                return mat.getEditorial();
            case 9:
                if (mat.getNumero() != 0) {
                    return mat.getNumero();
                }
                String numero = "No Aplica";
                return numero;
            case 10:
                if (mat.getVolumen() != 0) {
                    return mat.getVolumen();
                }
                String volumen = "No Aplica";
                return volumen;
            default:
                return "ND";
        }
    }

//    @Override
//    public String getColumnName(int column) {
//        return this.headers[column];
//    }
    @Override
    public String getColumnName(int column) {
        return this.columnas[column];
    }

    public Materiales getElement(int index) {
        return this.materiales.get(index);
    }
}

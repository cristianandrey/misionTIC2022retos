package Controller;

import DAO.MaterialesDAO;
import POJO.Materiales;
import java.util.ArrayList;

/**
 *
 * @author Cristian Andrey <cristianandrey.github.io/>
 */
public class ControllerMateriales {

    private MaterialesDAO matDAO;

    public ControllerMateriales() {
        this.matDAO = new MaterialesDAO();
    }

    public ArrayList<Materiales> getMaterial() {
        return (ArrayList<Materiales>) this.matDAO.getAll();
    }

    public boolean addMaterial(Materiales est) {
        return this.matDAO.create(est);
    }

    public Materiales getMaterial(int id) {
        return this.matDAO.get(id);
    }

    public boolean updateMaterial(Materiales mat) {
        return this.matDAO.update(mat);
    }

}

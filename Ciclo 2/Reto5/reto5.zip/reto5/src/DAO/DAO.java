
package DAO;

import java.util.List;

/**
 *
 * @author Cristian Andrey <cristianandrey.github.io/>
 */
public interface DAO<T> {

    boolean create(T object);

    List<T> getAll();

    T get(int id);

    boolean delete(int id);

    boolean update(T object);

}

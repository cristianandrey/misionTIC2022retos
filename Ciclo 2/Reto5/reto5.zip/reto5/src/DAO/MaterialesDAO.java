package DAO;

import DB.Conexion;
import POJO.Materiales;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Cristian Andrey <cristianandrey.github.io/>
 */
public class MaterialesDAO implements DAO<Materiales> {

    private Conexion conexion;

    public MaterialesDAO() {
        conexion = Conexion.getInstance();
    }

    @Override
    public boolean create(Materiales object) {
        boolean flag = false;
        try {

            if (object.getAutorprincipal()==null) {
                String sql = "insert into materiales values (NULL, false,?,?,?,?,?)";
                PreparedStatement pStm = this.conexion.getConnection().prepareStatement(sql);
                pStm.setString(1, object.getCodigo());
                pStm.setString(2, object.getTitulo());
                pStm.setString(3, object.getTematica());
                pStm.setInt(4, object.getAño_publicacion());
                pStm.setString(5, object.getEditorial());

                int rsU = pStm.executeUpdate();

                //AÑADIR A REVISTAS LA RELACION
                String sqlR = "SELECT id FROM `materiales` WHERE codigo=? ";
                PreparedStatement pStmR = this.conexion.getConnection().prepareStatement(sqlR);

                pStmR.setString(1, object.getCodigo());
                ResultSet rsR = pStmR.executeQuery();
                int resul = 0;
                if (rsR.next()) {
                    resul = rsR.getInt(1);
                    System.out.println("resultado " + resul);
                    String sqlRevista = "insert into revista values (NULL,?,?,?)";
                    PreparedStatement pStmRevista = this.conexion.getConnection().prepareStatement(sqlRevista);
                    pStmRevista.setInt(1, object.getNumero());
                    pStmRevista.setInt(2, object.getVolumen());
                    pStmRevista.setInt(3, resul);

                    int rsUR = pStmRevista.executeUpdate();
                }

                if (rsU == 1) {
                    flag = true;
                }
            } else {
                //parte de libro
                String sqlL = "insert into materiales values (NULL, false,?,?,?,?,?)";
                PreparedStatement pStmL = this.conexion.getConnection().prepareStatement(sqlL);
                pStmL.setString(1, object.getCodigo());
                pStmL.setString(2, object.getTitulo());
                pStmL.setString(3, object.getTematica());
                pStmL.setInt(4, object.getAño_publicacion());
                pStmL.setString(5, object.getEditorial());
                int rsU=pStmL.executeUpdate();

                //AÑADIR A LIBROS LA RELACION
                String sqlL2 = "SELECT id FROM `materiales` WHERE codigo=?";
                PreparedStatement pStmL2 = this.conexion.getConnection().prepareStatement(sqlL2);

                pStmL2.setString(1, object.getCodigo());
                
               // System.out.println(object.getCodigo());
                ResultSet rsL = pStmL2.executeQuery();
                
                int resul = 0;
                if (rsL.next()) {
                    resul = rsL.getInt(1);
                    System.out.println("resultado " + resul);
                    String sqlLibro = "insert into libro values (NULL,?,?)";
                    PreparedStatement pStmLibro = this.conexion.getConnection().prepareStatement(sqlLibro);

                    pStmLibro.setString(1, object.getAutorprincipal());
                    pStmLibro.setInt(2, resul);
                   // System.out.println("objeto" + object.getAutorprincipal());

                    int rsUL = pStmLibro.executeUpdate();
                }

                if (rsU == 1) {
                    flag = true;
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(MaterialesDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return flag;
    }

    @Override
    public List<Materiales> getAll() {

        ArrayList<Materiales> materiales = new ArrayList<>();

        //ArrayList<> resultList2 = new ArrayList<>(revistas);
        //resultList2.addAll(libros);
        String sql = "SELECT * FROM `materiales`,`revista` WHERE revista.id_materiales=materiales.id;";
        String sql2 = "SELECT * FROM `materiales`,`libro` WHERE libro.id_materiales=materiales.id;";
        Materiales mat;
        Materiales mat2;
        try {
            PreparedStatement pStm = this.conexion.getConnection().prepareStatement(sql);
            PreparedStatement pStm2 = this.conexion.getConnection().prepareStatement(sql2);

            ResultSet rs = pStm.executeQuery();
            ResultSet rs2 = pStm2.executeQuery();
            if (rs != null) {
                while (rs.next()) {

                    int id = rs.getInt(1);
                    boolean estado = rs.getBoolean(2);
                    String codigo = rs.getString(3);
                    String titulo = rs.getString(4);
                    String tematica = rs.getString(5);
                    int año_publicacion = rs.getInt(6);

                    String editorial = rs.getString(7);

                    int numero = rs.getInt(9);
                    int volumen = rs.getInt(10);

                    mat = new Materiales(id, codigo, titulo, tematica, año_publicacion, editorial, numero, volumen);
                    mat.setEstado(estado);
                    materiales.add(mat);
                }

                rs.close();
            }
            if (rs2 != null) {
                while (rs2.next()) {
                    int id = rs2.getInt(1);
                    boolean estado = rs2.getBoolean(2);
                    String codigo = rs2.getString(3);
                    String titulo = rs2.getString(4);
                    String tematica = rs2.getString(5);
                    int año_publicacion = rs2.getInt(6);
                    String editorial = rs2.getString(7);

                    String autor_principal = rs2.getString(9);
                    mat = new Materiales(autor_principal, id, codigo, titulo, tematica, año_publicacion, editorial);
                    mat.setEstado(estado);
                    materiales.add(mat);
                }
                rs2.close();
            }
            pStm.close();
            pStm2.close();

        } catch (SQLException ex) {
            Logger.getLogger(MaterialesDAO.class
                    .getName()).log(Level.SEVERE, null, ex);
        }
        return materiales;
    }

    @Override
    public Materiales get(int id) {
        Materiales materiales = null;
        //String sql = "select * from estudiante where id=?";

        Materiales est;
        try {
            //PARA REVISTA
            String sql = "SELECT * FROM `materiales`,`revista` WHERE revista.id_materiales=materiales.id AND materiales.id=?";
            PreparedStatement pStm = this.conexion.getConnection().prepareStatement(sql);
            pStm.setInt(1, id);
            ResultSet rs = pStm.executeQuery();

            //PARA LIBRO
            String sqlL = "SELECT * FROM `materiales`,`libro` WHERE libro.id_materiales=materiales.id AND materiales.id=?";
            PreparedStatement pStmL = this.conexion.getConnection().prepareStatement(sqlL);
            pStmL.setInt(1, id);
            ResultSet rsL = pStmL.executeQuery();
            if (rs != null && rs.next()) {
                //numero, volumen, estado, codigo, titulo, tematica, año_publicacion, editorial);

                int numero = rs.getInt("numero");
                int volumen = rs.getInt("volumen");
                boolean estado = rs.getBoolean("estado");
                String codigo = rs.getString("codigo");
                String titulo = rs.getString("titulo");
                String tematica = rs.getString("tematica");
                int año_publicacion = rs.getInt("año_publicacion");
                String editorial = rs.getString("editorial");

                materiales = new Materiales(id, codigo, titulo, tematica, año_publicacion, editorial, numero, volumen);

                rs.close();
            }
            //libros
            if (rsL != null && rsL.next()) {
                boolean estado = rsL.getBoolean("estado");
                String codigo = rsL.getString("codigo");
                String titulo = rsL.getString("titulo");
                String tematica = rsL.getString("tematica");
                int año_publicacion = rsL.getInt("año_publicacion");
                String editorial = rsL.getString("editorial");
                String autor_principal = rsL.getString("autor");

                materiales = new Materiales(autor_principal, id, codigo, titulo, tematica, año_publicacion, editorial);

                rs.close();
            }

            pStm.close();

        } catch (SQLException ex) {
            Logger.getLogger(MaterialesDAO.class
                    .getName()).log(Level.SEVERE, null, ex);
        }
        return materiales;
    }

    @Override
    public boolean update(Materiales object) {
//"Codigo", "Titulo", "Tematica", "Año publicacion", "Autor principal", "editorial", "numero", "volumen"
        boolean flag = false;
        String sql = "UPDATE materiales SET codigo=?, titulo=?, tematica=?,año_publicacion=?, editorial=? WHERE id=?";
        try {
            PreparedStatement pStm = this.conexion.getConnection().prepareStatement(sql);
            pStm.setString(1, object.getCodigo());
            pStm.setString(2, object.getTitulo());
            pStm.setString(3, object.getTematica());
            pStm.setInt(4, object.getAño_publicacion());
            pStm.setString(5, object.getEditorial());
            pStm.setInt(6, object.getId());
            int Rid = object.getId();

            if (object.getAutorprincipal().isEmpty()) {

                int rs = pStm.executeUpdate();

                String sqlR = "UPDATE `materiales`,`revista` SET numero=?,volumen=? WHERE revista.id_materiales=materiales.id AND materiales.id=?";
                PreparedStatement pStmR = this.conexion.getConnection().prepareStatement(sqlR);
                pStmR.setInt(1, object.getNumero());
                pStmR.setInt(2, object.getVolumen());
                pStmR.setInt(3, Rid);
                System.out.println("id " + Rid);
                rs = pStmR.executeUpdate();

                if (rs == 1) {
                    flag = true;
                }
            } else {
                int rs = pStm.executeUpdate();

                String sqlL = "UPDATE `materiales`,`libro` SET autor=? WHERE libro.id_materiales=materiales.id AND materiales.id=?";
                PreparedStatement pStmL = this.conexion.getConnection().prepareStatement(sqlL);
                pStmL.setString(1, object.getAutorprincipal());
                pStmL.setInt(2, Rid);
                System.out.println("id " + Rid);
                rs = pStmL.executeUpdate();

                if (rs == 1) {
                    flag = true;
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(MaterialesDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return flag;

    }

    @Override
    public boolean delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

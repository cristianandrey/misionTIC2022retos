package DB;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Cristian Andrey <cristianandrey.github.io/>
 */
public class Conexion {
     private final String DRIVER = "com.mysql.cj.jdbc.Driver";
    private final String URL = "jdbc:mysql://localhost:3306/reto5";
    private final String USER = "root";
    private final String PASSWD = "";
    private Connection con;
    
    private static Conexion conexion=null;
    
    private Conexion() {
        try {
            Class.forName(DRIVER);
            this.con = DriverManager.getConnection(URL, USER, PASSWD);
        } catch (ClassNotFoundException ex) {
            System.out.println(ex.getMessage());
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }
    
    public static Conexion getInstance() {
        if (conexion==null) {
            conexion=new Conexion();
        }
        return conexion;
    }
    
    public Connection getConnection() {
        return this.con;
    }
    
    public void close() {
        try {
            this.con.close();
            conexion=null;
        } catch (SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}

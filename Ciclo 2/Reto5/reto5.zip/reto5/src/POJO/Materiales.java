package POJO;

/**
 *
 * @author Cristian Andrey <cristianandrey.github.io/>
 */
public class Materiales extends Libro {

    private String autor_principal;

    //para revistas
    public Materiales(int id, String codigo, String titulo, String tematica, int año_publicacion, String editorial, int numero, int volumen) {
        super(id, codigo, titulo, tematica, año_publicacion, editorial, numero, volumen);

    }

    public Materiales(String codigo, String titulo, String tematica, int año_publicacion, String editorial, int numero, int volumen) {
        super(0, codigo, titulo, tematica, año_publicacion, editorial, numero, volumen);

    }

    //para libro
    public Materiales(String autor_principal, int id, String codigo, String titulo, String tematica, int año_publicacion, String editorial) {
        super(id, codigo, titulo, tematica, año_publicacion, editorial);
        this.autor_principal = autor_principal;
    }

    public Materiales(String codigo, String titulo, String tematica, int año_publicacion, String editorial, String autor_principal) {
        super(0, codigo, titulo, tematica, año_publicacion, editorial);
        this.autor_principal = autor_principal;
    }

    public String getAutorprincipal() {
        return autor_principal;
    }

    public void setAutorprincipal(String autor_principal) {
        this.autor_principal = autor_principal;
    }

}

package POJO;

/**
 *
 * @author Cristian Andrey <cristianandrey.github.io/>
 */
public class Revista {
//
//    private int numero;
//    private int volumen;
//
//    public Revista(int numero, int volumen, int id, boolean estado, String codigo, String titulo, String tematica, int año_publicacion, String editorial) {
//        super(id, estado, codigo, titulo, tematica, año_publicacion, editorial);
//        this.numero = numero;
//        this.volumen = volumen;
//    }
//
//
//    public int getNumero() {
//        return numero;
//    }
//
//    public void setNumero(int numero) {
//        this.numero = numero;
//    }
//
//    public int getVolumen() {
//        return volumen;
//    }
//
//    public void setVolumen(int volumen) {
//        this.volumen = volumen;
//    }

}

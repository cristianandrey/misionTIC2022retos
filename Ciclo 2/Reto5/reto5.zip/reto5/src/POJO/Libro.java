package POJO;

/**
 *
 * @author Cristian Andrey <cristianandrey.github.io/>
 */
public class Libro {

    private int id;

    private boolean estado = false;
    private String codigo;
    private String titulo;
    private String tematica;
    private int año_publicacion;
    private String editorial;
    private int numero;
    private int volumen;

    //revistas
    public Libro(int id, String codigo, String titulo, String tematica, int año_publicacion, String editorial, int numero, int volumen) {
        this.id = id;
        this.codigo = codigo;
        this.titulo = titulo;
        this.tematica = tematica;
        this.año_publicacion = año_publicacion;
        this.editorial = editorial;
        this.numero = numero;
        this.volumen = volumen;
    }

    //para libros
    public Libro(int id, String codigo, String titulo, String tematica, int año_publicacion, String editorial) {
        this.id = id;
        this.codigo = codigo;
        this.titulo = titulo;
        this.tematica = tematica;
        this.año_publicacion = año_publicacion;
        this.editorial = editorial;

    }

    public Libro() {

    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public int getVolumen() {
        return volumen;
    }

    public void setVolumen(int volumen) {
        this.volumen = volumen;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public boolean getEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getTematica() {
        return tematica;
    }

    public void setTematica(String tematica) {
        this.tematica = tematica;
    }

    public int getAño_publicacion() {
        return año_publicacion;
    }

    public void setAño_publicacion(int año_publicacion) {
        this.año_publicacion = año_publicacion;
    }

    public String getEditorial() {
        return editorial;
    }

    public void setEditorial(String editorial) {
        this.editorial = editorial;
    }

//    private String autor_principal;
////contructor de revistas
//
//    public Libro(String autor_principal, int id, String codigo, String titulo, String tematica, int año_publicacion, String editorial, int numero, int volumen) {
//        super(id, codigo, titulo, tematica, año_publicacion, editorial, numero, volumen);
//
//    }
////para libro
//
//    public Libro(String autor_principal, int id, String codigo, String titulo, String tematica, int año_publicacion, String editorial) {
//        super(id, codigo, titulo, tematica, año_publicacion, editorial);
//        this.autor_principal = autor_principal;
//    }
//
//    public String getAutor_principal() {
//        return autor_principal;
//    }
//
//    public void setAutor_principal(String autor_principal) {
//        this.autor_principal = autor_principal;
//    }
}
